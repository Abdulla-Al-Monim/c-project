﻿namespace Slim_Fit_Helth_Gym.View
{
    partial class ShowMember
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ShowMember));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.buttonProgram = new System.Windows.Forms.Button();
            this.buttonTrainer = new System.Windows.Forms.Button();
            this.buttonRegistation = new System.Windows.Forms.Button();
            this.buttonBack = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonLogOut = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.buttonRemove = new System.Windows.Forms.Button();
            this.textBoxDelete = new System.Windows.Forms.TextBox();
            this.buttonSearch = new System.Windows.Forms.Button();
            this.textBoxSearch = new System.Windows.Forms.TextBox();
            this.dataGridViewMember = new System.Windows.Forms.DataGridView();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.bindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.buttonBackAdmin = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMember)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.groupBox1.Controls.Add(this.buttonProgram);
            this.groupBox1.Controls.Add(this.buttonTrainer);
            this.groupBox1.Controls.Add(this.buttonRegistation);
            this.groupBox1.Controls.Add(this.buttonBackAdmin);
            this.groupBox1.Controls.Add(this.buttonBack);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(-3, 40);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(830, 113);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            // 
            // buttonProgram
            // 
            this.buttonProgram.Location = new System.Drawing.Point(382, 14);
            this.buttonProgram.Name = "buttonProgram";
            this.buttonProgram.Size = new System.Drawing.Size(75, 23);
            this.buttonProgram.TabIndex = 8;
            this.buttonProgram.Text = "Program";
            this.buttonProgram.UseVisualStyleBackColor = true;
            this.buttonProgram.Click += new System.EventHandler(this.buttonProgram_Click);
            // 
            // buttonTrainer
            // 
            this.buttonTrainer.Location = new System.Drawing.Point(267, 14);
            this.buttonTrainer.Name = "buttonTrainer";
            this.buttonTrainer.Size = new System.Drawing.Size(75, 23);
            this.buttonTrainer.TabIndex = 7;
            this.buttonTrainer.Text = "Trainer";
            this.buttonTrainer.UseVisualStyleBackColor = true;
            this.buttonTrainer.Click += new System.EventHandler(this.buttonTrainer_Click);
            // 
            // buttonRegistation
            // 
            this.buttonRegistation.Location = new System.Drawing.Point(137, 11);
            this.buttonRegistation.Name = "buttonRegistation";
            this.buttonRegistation.Size = new System.Drawing.Size(75, 23);
            this.buttonRegistation.TabIndex = 5;
            this.buttonRegistation.Text = "Registation";
            this.buttonRegistation.UseVisualStyleBackColor = true;
            this.buttonRegistation.Click += new System.EventHandler(this.buttonRegClick);
            // 
            // buttonBack
            // 
            this.buttonBack.BackgroundImage = global::Slim_Fit_Helth_Gym.Properties.Resources.Icon_29;
            this.buttonBack.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonBack.FlatAppearance.BorderSize = 0;
            this.buttonBack.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttonBack.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.buttonBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonBack.Location = new System.Drawing.Point(6, 14);
            this.buttonBack.Name = "buttonBack";
            this.buttonBack.Size = new System.Drawing.Size(35, 23);
            this.buttonBack.TabIndex = 5;
            this.buttonBack.UseVisualStyleBackColor = true;
            this.buttonBack.Visible = false;
            this.buttonBack.Click += new System.EventHandler(this.buttonBack_Click);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.BackColor = System.Drawing.Color.SteelBlue;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(679, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(145, 55);
            this.label1.TabIndex = 0;
            this.label1.Text = "Member List";
            // 
            // buttonLogOut
            // 
            this.buttonLogOut.Location = new System.Drawing.Point(718, 528);
            this.buttonLogOut.Name = "buttonLogOut";
            this.buttonLogOut.Size = new System.Drawing.Size(75, 23);
            this.buttonLogOut.TabIndex = 5;
            this.buttonLogOut.Text = "Log Out";
            this.buttonLogOut.UseVisualStyleBackColor = true;
            this.buttonLogOut.Click += new System.EventHandler(this.buttonLog_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.BackColor = System.Drawing.Color.DimGray;
            this.groupBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.groupBox2.Controls.Add(this.buttonRemove);
            this.groupBox2.Controls.Add(this.textBoxDelete);
            this.groupBox2.Controls.Add(this.buttonSearch);
            this.groupBox2.Controls.Add(this.textBoxSearch);
            this.groupBox2.Location = new System.Drawing.Point(-3, 94);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(830, 147);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            // 
            // buttonRemove
            // 
            this.buttonRemove.Location = new System.Drawing.Point(231, 29);
            this.buttonRemove.Name = "buttonRemove";
            this.buttonRemove.Size = new System.Drawing.Size(75, 23);
            this.buttonRemove.TabIndex = 5;
            this.buttonRemove.Text = "Remove";
            this.buttonRemove.UseVisualStyleBackColor = true;
            this.buttonRemove.Click += new System.EventHandler(this.buttonRemove_Click);
            // 
            // textBoxDelete
            // 
            this.textBoxDelete.Location = new System.Drawing.Point(30, 32);
            this.textBoxDelete.Name = "textBoxDelete";
            this.textBoxDelete.Size = new System.Drawing.Size(172, 20);
            this.textBoxDelete.TabIndex = 6;
            // 
            // buttonSearch
            // 
            this.buttonSearch.Location = new System.Drawing.Point(721, 30);
            this.buttonSearch.Name = "buttonSearch";
            this.buttonSearch.Size = new System.Drawing.Size(75, 23);
            this.buttonSearch.TabIndex = 4;
            this.buttonSearch.Text = "Search";
            this.buttonSearch.UseVisualStyleBackColor = true;
            this.buttonSearch.Click += new System.EventHandler(this.buttonSearch_Click_2);
            // 
            // textBoxSearch
            // 
            this.textBoxSearch.Location = new System.Drawing.Point(542, 31);
            this.textBoxSearch.Name = "textBoxSearch";
            this.textBoxSearch.Size = new System.Drawing.Size(161, 20);
            this.textBoxSearch.TabIndex = 3;
            // 
            // dataGridViewMember
            // 
            this.dataGridViewMember.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewMember.BackgroundColor = System.Drawing.Color.Gainsboro;
            this.dataGridViewMember.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewMember.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewMember.Location = new System.Drawing.Point(3, 247);
            this.dataGridViewMember.Name = "dataGridViewMember";
            this.dataGridViewMember.Size = new System.Drawing.Size(809, 275);
            this.dataGridViewMember.TabIndex = 0;
            this.dataGridViewMember.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewMember_CellClick);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // buttonBackAdmin
            // 
            this.buttonBackAdmin.BackgroundImage = global::Slim_Fit_Helth_Gym.Properties.Resources.Icon_29;
            this.buttonBackAdmin.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonBackAdmin.FlatAppearance.BorderSize = 0;
            this.buttonBackAdmin.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DimGray;
            this.buttonBackAdmin.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.buttonBackAdmin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonBackAdmin.Location = new System.Drawing.Point(47, 14);
            this.buttonBackAdmin.Name = "buttonBackAdmin";
            this.buttonBackAdmin.Size = new System.Drawing.Size(35, 23);
            this.buttonBackAdmin.TabIndex = 5;
            this.buttonBackAdmin.UseVisualStyleBackColor = true;
            this.buttonBackAdmin.Visible = false;
            this.buttonBackAdmin.Click += new System.EventHandler(this.buttonBack_Click);
            // 
            // ShowMember
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(823, 553);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.buttonLogOut);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dataGridViewMember);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ShowMember";
            this.Text = "Member List";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ShowMember_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.ShowMember_FormClosed);
            this.Load += new System.EventHandler(this.ShowMember_Load);
            this.BindingContextChanged += new System.EventHandler(this.ShowMember_BindingContextChanged);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewMember)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxSearch;
        private System.Windows.Forms.Button buttonSearch;
        private System.Windows.Forms.Button buttonRemove;
        private System.Windows.Forms.Button buttonRegistation;
        private System.Windows.Forms.Button buttonLogOut;
        private System.Windows.Forms.TextBox textBoxDelete;
        private System.Windows.Forms.Button buttonProgram;
        private System.Windows.Forms.Button buttonTrainer;
        private System.Windows.Forms.GroupBox groupBox2;
        public System.Windows.Forms.DataGridView dataGridViewMember;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.BindingSource bindingSource;
        internal System.Windows.Forms.Button buttonBackAdmin;
        internal System.Windows.Forms.Button buttonBack;
    }
}