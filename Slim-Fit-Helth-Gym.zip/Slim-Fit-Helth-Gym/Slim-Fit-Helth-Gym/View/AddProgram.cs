﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Slim_Fit_Helth_Gym.Controller;

namespace Slim_Fit_Helth_Gym.View
{
    public partial class AddProgram : Form
    {
        public AddProgram()
        {
            InitializeComponent();
        }

        private void AddProgram_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void AddProgram_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void buttonConfarm_Click(object sender, EventArgs e)
        {
            ProgramController.AddProgram(textBoxName.Text,textBoxNOF.Text,textBoxCost.Text);
            textBoxName.Text = "";
            textBoxNOF.Text = "";
            textBoxCost.Text = "";
        }

        private void AddProgram_Load(object sender, EventArgs e)
        {

        }

        private void buttonHomeClick(object sender, EventArgs e)
        {
            this.Hide();
            new AdminHome().Show();
        }
    }
}
