﻿namespace Slim_Fit_Helth_Gym.View
{
    partial class AdminHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminHome));
            this.buttonAddBranch = new System.Windows.Forms.Button();
            this.ButtonTrainer = new System.Windows.Forms.Button();
            this.buttonProgram = new System.Windows.Forms.Button();
            this.buttonManager = new System.Windows.Forms.Button();
            this.buttonManagerReg = new System.Windows.Forms.Button();
            this.buttonLogOut = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonAddBranch
            // 
            this.buttonAddBranch.Location = new System.Drawing.Point(95, 12);
            this.buttonAddBranch.Name = "buttonAddBranch";
            this.buttonAddBranch.Size = new System.Drawing.Size(75, 23);
            this.buttonAddBranch.TabIndex = 0;
            this.buttonAddBranch.Text = "Add Branch";
            this.buttonAddBranch.UseVisualStyleBackColor = true;
            this.buttonAddBranch.Click += new System.EventHandler(this.buttonAddBranch_Click);
            // 
            // ButtonTrainer
            // 
            this.ButtonTrainer.Location = new System.Drawing.Point(206, 12);
            this.ButtonTrainer.Name = "ButtonTrainer";
            this.ButtonTrainer.Size = new System.Drawing.Size(75, 23);
            this.ButtonTrainer.TabIndex = 0;
            this.ButtonTrainer.Text = "Trainer";
            this.ButtonTrainer.UseVisualStyleBackColor = true;
            this.ButtonTrainer.Click += new System.EventHandler(this.ButtonTrainer_Click);
            // 
            // buttonProgram
            // 
            this.buttonProgram.Location = new System.Drawing.Point(324, 12);
            this.buttonProgram.Name = "buttonProgram";
            this.buttonProgram.Size = new System.Drawing.Size(75, 23);
            this.buttonProgram.TabIndex = 0;
            this.buttonProgram.Text = "Program";
            this.buttonProgram.UseVisualStyleBackColor = true;
            this.buttonProgram.Click += new System.EventHandler(this.buttonProgram_Click);
            // 
            // buttonManager
            // 
            this.buttonManager.Location = new System.Drawing.Point(451, 12);
            this.buttonManager.Name = "buttonManager";
            this.buttonManager.Size = new System.Drawing.Size(75, 23);
            this.buttonManager.TabIndex = 0;
            this.buttonManager.Text = "Manager";
            this.buttonManager.UseVisualStyleBackColor = true;
            this.buttonManager.Click += new System.EventHandler(this.buttonManager_Click);
            // 
            // buttonManagerReg
            // 
            this.buttonManagerReg.Location = new System.Drawing.Point(566, 12);
            this.buttonManagerReg.Name = "buttonManagerReg";
            this.buttonManagerReg.Size = new System.Drawing.Size(110, 23);
            this.buttonManagerReg.TabIndex = 1;
            this.buttonManagerReg.Text = "Manager Reg";
            this.buttonManagerReg.UseVisualStyleBackColor = true;
            this.buttonManagerReg.Click += new System.EventHandler(this.buttonManagerReg_Click);
            // 
            // buttonLogOut
            // 
            this.buttonLogOut.Location = new System.Drawing.Point(586, 415);
            this.buttonLogOut.Name = "buttonLogOut";
            this.buttonLogOut.Size = new System.Drawing.Size(75, 23);
            this.buttonLogOut.TabIndex = 2;
            this.buttonLogOut.Text = "Log Out";
            this.buttonLogOut.UseVisualStyleBackColor = true;
            this.buttonLogOut.Click += new System.EventHandler(this.buttonLogOut_Click);
            // 
            // AdminHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonLogOut);
            this.Controls.Add(this.buttonManagerReg);
            this.Controls.Add(this.buttonManager);
            this.Controls.Add(this.buttonProgram);
            this.Controls.Add(this.ButtonTrainer);
            this.Controls.Add(this.buttonAddBranch);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AdminHome";
            this.Text = "AdminHome";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.AdminHome_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.AdminHome_FormClosed);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonAddBranch;
        private System.Windows.Forms.Button ButtonTrainer;
        private System.Windows.Forms.Button buttonProgram;
        private System.Windows.Forms.Button buttonManager;
        private System.Windows.Forms.Button buttonManagerReg;
        private System.Windows.Forms.Button buttonLogOut;
    }
}