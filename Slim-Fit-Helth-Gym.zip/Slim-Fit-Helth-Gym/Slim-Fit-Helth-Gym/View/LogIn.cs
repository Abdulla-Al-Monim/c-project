﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Slim_Fit_Helth_Gym.Controller;

namespace Slim_Fit_Helth_Gym.View
{
    public partial class LogIn : Form
    {
        public LogIn()
        {
            InitializeComponent();
        }

        private void LogIn_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void buttonLogClick(object sender, EventArgs e)
        {

            var result = LoginController.AuthenticateUser(textBoxName.Text, textBoxPassword.Text);
            if (result == true)
            {
                new HomePage().Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Failure", "Alert");
            }


        }

        private void LogIn_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void LogIn_Load(object sender, EventArgs e)
        {

        }

        private void buttonSignUp_Click(object sender, EventArgs e)
        {
            buttonLogIn.BackColor = Color.Transparent;

        }

        private void buttonLogIn_BackColorChanged(object sender, EventArgs e)
        {
            buttonLogIn.BackColor = Color.Transparent;

        }

        private void buttonLogIn_Click(object sender, EventArgs e)
        {
            if (textBoxType.Text == "Admin")
            {
                var result = LoginController.AuthenticateUserAdmin(textBoxName.Text, textBoxPassword.Text);
                if (result == true)
                {
                    new AdminHome().Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Failure", "Alert");
                }
            }
            else if (textBoxType.Text == "Manager")
            {
                var result = LoginController.AuthenticateUser(textBoxName.Text, textBoxPassword.Text);
                if (result == true)
                {
                    new HomePage().Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Failure", "Alert");
                }
            }
            
        }

        private void buttonSignUp_Click_1(object sender, EventArgs e)
        {

        }

        private void buttonSignUp_Click_2(object sender, EventArgs e)
        {
            
        }
    }
}
