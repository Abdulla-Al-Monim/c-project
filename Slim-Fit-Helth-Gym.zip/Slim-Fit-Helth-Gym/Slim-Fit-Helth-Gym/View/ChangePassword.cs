﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Slim_Fit_Helth_Gym.Controller;

namespace Slim_Fit_Helth_Gym.View
{
    public partial class ChangePassword : Form
    {
        public ChangePassword()
        {
            InitializeComponent();
        }

        private void SignUp_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void SignUp_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void change_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void textBoxPas_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttonChange_Click(object sender, EventArgs e)
        {
            var result = LoginController.AuthenticateUser(textBoxId.Text, textBoxPas.Text);
            if (result == true)
            {
                
                buttonConfarm.Visible = true;
            }
            else
            {
                MessageBox.Show("Failure", "Alert");
            }
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            
        }

        private void buttonConfarm_Click(object sender, EventArgs e)
        {
            string te;
            te = textBoxConfarmPass.Text;
            var result = ManagerController.AuthenticateManager(textBoxId.Text, textBoxPas.Text);
            if (result == true)
            {
                if (textBoxNewPAss.Text!=textBoxPas.Text)
                {
                    if (textBoxNewPAss.Text.Equals(te))
                    {
                        ManagerController.ChangePassManager(textBoxId.Text, te);
                        MessageBox.Show("Success");
                        textBoxId.Text = "";
                        textBoxPas.Text = "";
                        textBoxNewPAss.Text = "";
                        textBoxConfarmPass.Text = "";
                    }
                    else
                    {
                        MessageBox.Show("Password not match ", "Please try new Password");
                    }
                    
                }
                else
                {
                    MessageBox.Show("You can not add old Password ", "Please try new Password");
                }
            }
            else
            {
                MessageBox.Show("Incorret Old Pass", "Please try Again");
            }
            
        }

        private void buttonlog_Click(object sender, EventArgs e)
        {
            this.Hide();
            new HomePage().Show();
        }
    }
}
