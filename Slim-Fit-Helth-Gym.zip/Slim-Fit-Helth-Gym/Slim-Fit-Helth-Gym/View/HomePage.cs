﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Slim_Fit_Helth_Gym.Controller;
namespace Slim_Fit_Helth_Gym.View
{
    public partial class HomePage : Form
    {
        public HomePage()
        {
            InitializeComponent();
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void HomePage_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void HomePage_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void HomePage_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void button_View_memberClick(object sender, EventArgs e)
        {
            this.Hide();

            //var categories = CategoryController.GetAllCategories();
            // var Members = MemberController.GetAllMembers();
            ShowMember m = new ShowMember();
            m.buttonBack.Visible = true;
            // var MemberCatagories = CategoryController.GetAllMemberCategories();
            //  new ShowMember(Members, MemberCatagories).Show();


        }

        private void buttonRegistation_Click(object sender, EventArgs e)
        {
            //this.Hide();
            
            groupBoxReg.Visible = true;
            buttonBackReg.Visible = true;
        }

        private void buttonLogOut_Click(object sender, EventArgs e)
        {
            this.Hide();
            new LogIn().Show();
        }

        private void buttonCalander_Click(object sender, EventArgs e)
        {
            dateTimePicker.Visible = false;
            buttonCalanderHide.Visible = false;
            buttonCalanderShow.Visible = true;

        }

        private void groupBoxCalander_Enter(object sender, EventArgs e)
        {
            
        }

        private void buttonCalanderShowClick(object sender, EventArgs e)
        {
            dateTimePicker.Visible = true;
            buttonCalanderHide.Visible = true;
            //buttonCalanderShow.Visible = false;



        }

        private void button_TrainerREmoveClick(object sender, EventArgs e)
        {
            
        }

        private void buttonTrainerClick(object sender, EventArgs e)
        {
            this.Hide();
            Trainers t = new Trainers();
            t.buttonBack.Visible = true;
            t.Show();
        }

        private void buttonREmoveClick(object sender, EventArgs e)
        {
           
        }

        private void groupBoxRemobeMember_Enter(object sender, EventArgs e)
        {

        }

        private void buttonRemoveTClick(object sender, EventArgs e)
        {
            
        }

        private void button_BackClick(object sender, EventArgs e)
        {
            
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBoxMember_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttonTmoveClick(object sender, EventArgs e)
        {
            
        }

        private void buttonBackClick(object sender, EventArgs e)
        {
           
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            //monthCalendar2.Visible = true;
        }

        private void groupBoxCalander_Layout(object sender, LayoutEventArgs e)
        {

        }

        private void buttonMemberReg_Click(object sender, EventArgs e)
        {
            this.Hide();
            Registation r = new Registation();
            r.Visible = true;
            r.buttonBack.Visible = true;

        }

        private void buttonBackHomeClick(object sender, EventArgs e)
        {
            groupBoxReg.Visible = false;
        }

        private void dateTimePicker_ValueChanged(object sender, EventArgs e)
        {

        }

        private void buttonTrainerReg_Click(object sender, EventArgs e)
        {
            this.Hide();
            new TrainerReg().Show();
        }

        private void buttonProgram_Click(object sender, EventArgs e)
        {
            this.Hide();
            Programs p = new Programs();
            p.Show();
            p.buttonHome.Visible = true;
        }

        private void buttonPassChange_Click(object sender, EventArgs e)
        {
            this.Hide();
            new ChangePassword().Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
