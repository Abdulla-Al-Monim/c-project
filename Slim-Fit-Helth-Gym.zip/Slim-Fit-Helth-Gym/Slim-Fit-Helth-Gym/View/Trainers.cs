﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Slim_Fit_Helth_Gym.Controller;

namespace Slim_Fit_Helth_Gym.View
{
    public partial class Trainers : Form
    {
        public Trainers()
        {
            InitializeComponent();
        }

        private void Trainers_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();

        }

        private void Trainers_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void Trainers_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = TrainerController.GetAllTraainers();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void buttonRemoveB_Click(object sender, EventArgs e)
        {
            TrainerController.DeleteTrainer(textBoxRemoveT.Text);
            dataGridView1.DataSource = TrainerController.GetAllTraainers();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            new HomePage().Show();
        }

        private void buttonreg_Click(object sender, EventArgs e)
        {
            this.Hide();
            new TrainerReg().Show();
        }

        private void buttontck(object sender, EventArgs e)
        {
           dataGridView1.DataSource= TrainerController.GetAllTrainersSearch(textBoxSearch.Text);
            textBoxSearch.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            new LogIn().Show();
        }

        private void buttonBackAdmin_Click(object sender, EventArgs e)
        {
            this.Hide();
            new AdminHome().Show();
        }
    }
}
