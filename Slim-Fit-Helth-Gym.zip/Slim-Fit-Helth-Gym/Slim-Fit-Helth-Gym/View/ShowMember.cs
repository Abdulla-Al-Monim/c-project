﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Slim_Fit_Helth_Gym.Controller;

namespace Slim_Fit_Helth_Gym.View
{
    public partial class ShowMember : Form
    {
        int Count = 0;
       
        public ShowMember()
        {
            InitializeComponent();
           
        }
        public ShowMember(ArrayList member)
        {
            InitializeComponent();
            //dataGridViewMember.DataSource = member;
            

        }



        private void DataGridViewMember_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Student_Click(object sender, EventArgs e)
        {

        }

        private void ShowMember_Load(object sender, EventArgs e)
        {
           // dataGridViewMember.bi

            dataGridViewMember.DataSource = MemberController.GetAllMembers();
           
            
        }

        private void ShowMember_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void ShowMember_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void ButtonSearch_Click(object sender, EventArgs e)
        {
           
            dataGridViewMember.DataSource = MemberController.SearchMember(textBoxSearch.Text);
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            new HomePage().Show();
        }

        private void ButtonRemovememberClick(object sender, EventArgs e)
        {
            MemberController.DeleteMember(textBoxDelete.Text);
          //  dataGridViewMember.DataSource = MemberController.GetAllMembers();
        }

        private void buttonSearch_Click_1(object sender, EventArgs e)
        {

        }

        private void buttonSearch_Click_2(object sender, EventArgs e)
        {
            dataGridViewMember.DataSource = MemberController.SearchMember(textBoxSearch.Text);
            
        }

        private void buttonRemove_Click(object sender, EventArgs e)
        {
            MemberController.DeleteMember(textBoxDelete.Text);
            dataGridViewMember.DataSource = MemberController.GetAllMembers();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Count = bindingSource.Count;
           // label2.Text = Count.ToString();
        }

        private void ShowMember_BindingContextChanged(object sender, EventArgs e)
        {

        }

        private void bindingNavigator1_RefreshItems(object sender, EventArgs e)
        {

        }

        private void bindingNavigatorDeleteItem_Click(object sender, EventArgs e)
        {
            
        }

        private void dataGridViewMember_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow rw = dataGridViewMember.CurrentRow;
            string id = rw.Cells["Id"].Value.ToString();
            textBoxDelete.Text = id;

        }

        private void buttonTrainer_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Trainers().Show();
        }

        private void buttonProgram_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Programs().Show();
        }

        private void buttonRegClick(object sender, EventArgs e)
        {
            this.Hide();
            new Registation().Show();
        }

        private void buttonLog_Click(object sender, EventArgs e)
        {
            this.Hide();
            new LogIn().Show();
        }
    }
}
