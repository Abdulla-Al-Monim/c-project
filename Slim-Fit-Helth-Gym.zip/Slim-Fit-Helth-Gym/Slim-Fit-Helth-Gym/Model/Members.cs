﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Slim_Fit_Helth_Gym.View;
namespace Slim_Fit_Helth_Gym.Model

{
    class Members
    {
        SqlConnection conn;
        public int x;
        public Members()
        {
            try
            {
                conn = new SqlConnection("Server=DESKTOP-O3VM4NP;Database=Slimfit;User Id=sa;Password=12345678;");
            }
            catch(Exception Ee)
            {
               
            }
            
        }
        public void AddMember(Member member)
        {
            try
            {
                conn.Open();
                string query = "INSERT INTO Members (Id,Name,DOB,Gender,Email,Phone,Branch,CategoryName,TrainerId,ProgramName) VALUES('" + member.Id + "','" + member.Name + "','" + member.DOB + "','" + member.Gender + "','" + member.Email + "','" + member.Phone + "','" + member.Branch + "','" + member.CategoryName + "','" + member.TrainerId + "','" + member.ProgramName + "')";
                SqlCommand cmd = new SqlCommand(query, conn);
                int result = cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception e)
            {
                conn.Close();
            }
            
                    

        }
        public void DeleteMember(Member member)
        {
            conn.Open();
            
                string query = "DELETE FROM Members where Id='" + member.Id + "'";
            
            
            SqlCommand cmd = new SqlCommand(query, conn);
            int result = cmd.ExecuteNonQuery();
            conn.Close();
        }
        
        public void UpdateMembher(Member member)
        {
            
        }
        public Member GetMember(string memberName)
        {
            Member member = new Member();

            return member;
        }
        public ArrayList GetAllMembers()
        {
           
                ArrayList Members = new ArrayList();

                conn.Open();
                string query = "SELECT Id,Name,Gender,Email,Phone,Branch,TrainerId,ProgramName,CategoryName FROM Members";
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Member m = new Member();

                    m.Id = reader.GetString(reader.GetOrdinal("Id"));
                    m.Name = reader.GetString(reader.GetOrdinal("Name"));
                    m.Gender = reader.GetString(reader.GetOrdinal("Gender"));
                    m.Email = reader.GetString(reader.GetOrdinal("Email"));
                    m.Phone = reader.GetString(reader.GetOrdinal("Phone"));
                    m.Branch = reader.GetString(reader.GetOrdinal("Branch"));
                    m.TrainerId = reader.GetString(reader.GetOrdinal("TrainerId"));
                    m.CategoryName = reader.GetString(reader.GetOrdinal("CategoryName"));
                    m.ProgramName = reader.GetString(reader.GetOrdinal("ProgramName"));



                    Members.Add(m);
                }
                conn.Close();
                return Members;
            
        }


        public ArrayList GetAllMembersSearch(string search)
        {
            ArrayList Members = new ArrayList();

            conn.Open();
            string query;
            if (search.Equals("all") || search.Equals("All"))
            {
                query = "SELECT Id,Name,Gender,Email,Phone,Branch,TrainerId,ProgramName,CategoryName FROM Members";
            }
            else
            {
                query = "SELECT Id,Name,Gender,Email,Phone,Branch,TrainerId,ProgramName,CategoryName FROM Members Where Id ='" + search + "' or Name ='" + search + "' or Gender ='" + search + "'or Email ='" + search + "' or Email ='" + search + "' or Phone ='" + search + "'or Branch ='" + search + "' or TrainerId ='" + search + "' or ProgramName ='" + search + "' or CategoryName ='" + search + "'";
            }
            SqlCommand cmd = new SqlCommand(query, conn);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Member m = new Member();
               

                m.Id = reader.GetString(reader.GetOrdinal("Id"));
                m.Name = reader.GetString(reader.GetOrdinal("Name"));
                m.Gender = reader.GetString(reader.GetOrdinal("Gender"));
                m.Email = reader.GetString(reader.GetOrdinal("Email"));
                m.Phone = reader.GetString(reader.GetOrdinal("Phone"));
                m.Branch = reader.GetString(reader.GetOrdinal("Branch"));
                m.TrainerId = reader.GetString(reader.GetOrdinal("TrainerId"));
                m.CategoryName = reader.GetString(reader.GetOrdinal("CategoryName"));
                m.ProgramName = reader.GetString(reader.GetOrdinal("ProgramName"));



                Members.Add(m);
            }
            conn.Close();
            return Members;
        }


    }
}
