﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Slim_Fit_Helth_Gym.View;
namespace Slim_Fit_Helth_Gym.Model


{
    class Admins
    {
        SqlConnection conn;
        
        public Admins()
        {
            try
            {
                conn = new SqlConnection("Server=DESKTOP-O3VM4NP;Database=Slimfit;User Id=sa;Password=12345678;");
            }
            catch (Exception Ee)
            {

            }

        }
        public Admin AuthenticateUserAdmin(string adminName, string adminPassword)
        {
            try
            {
                conn.Open();
                Admin a = null;
                string query = "SELECT * FROM Admins WHERE AdminName='" + adminName + "' and AdminPassword='" + adminPassword + "'";
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    a = new Admin();
                    a.AdminId = reader.GetString(reader.GetOrdinal("AdminId"));
                    a.AdminName = reader.GetString(reader.GetOrdinal("AdminName"));
                    a.AdminPassword= reader.GetString(reader.GetOrdinal("AdminPassword"));
                    
                }
                conn.Close();
                return a;
            }
            catch (Exception e)
            {
                return null;
            }


        }
    }
}
