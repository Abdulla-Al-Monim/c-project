﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
namespace Slim_Fit_Helth_Gym.Model
{
    class Trainers
    {
        SqlConnection conn;
        public Trainers()
        {
            
                conn = new SqlConnection("Server=DESKTOP-O3VM4NP;Database=Slimfit;User Id=sa;Password=12345678;");
            
        }
        public void AddTrainer(Trainer trainer)
        {
            try
            {
                conn.Open();

                string query = "INSERT INTO Trainers (TrainerId,TrainerName,TrainerDOB,TrainerGender,TrainerEmail,TrainerPhone,TrainerBranch,Salary) VALUES('" + trainer.TrainerId + "','" + trainer.TrainerName + "','" + trainer.TrainerDOB + "','" + trainer.TrainerGender + "','" + trainer.TrainerEmail + "','" + trainer.TrainerPhone + "','" + trainer.TrainerBranch + "','" + trainer.salary + "')";
                SqlCommand cmd = new SqlCommand(query, conn);
                int result = cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine("exception Caught"+e.Message);
                conn.Close();
            }
            
            

            
        }
        public void DeleteTrainer(Trainer trainer)
        {
            conn.Open();
            string query = "DELETE FROM Trainers where TrainerId='" + trainer.TrainerId + "'";


            SqlCommand cmd = new SqlCommand(query, conn);
            int result = cmd.ExecuteNonQuery();
            conn.Close();
        }
        public ArrayList GetAlltrainers()
        {
            ArrayList Trainers = new ArrayList();
            conn.Open();
            string query = "SELECT * FROM Trainers";
            SqlCommand cmd = new SqlCommand(query, conn);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Trainer t = new Trainer()
                {
                    TrainerId = reader.GetString(reader.GetOrdinal("TrainerId")),
                    TrainerName= reader.GetString(reader.GetOrdinal("TrainerName")),
                    TrainerDOB = reader.GetString(reader.GetOrdinal("TrainerDOB")),
                    TrainerGender = reader.GetString(reader.GetOrdinal("TrainerGender")),
                    TrainerEmail = reader.GetString(reader.GetOrdinal("TrainerEmail")),
                    TrainerPhone = reader.GetString(reader.GetOrdinal("TrainerPhone")),
                    TrainerBranch = reader.GetString(reader.GetOrdinal("TrainerBranch")),
                    salary = reader.GetInt32(reader.GetOrdinal("Salary")),
                };
                Trainers.Add(t);
            }
            conn.Close();
            return Trainers;

        }
        string query;
        public ArrayList GetAlltrainersSearch(string search)
        {
            int i = 0;
            ArrayList Trainers = new ArrayList();
            conn.Open();
            
            if (search.Equals("all"))
            {
                query = "SELECT * FROM Trainers";
            }
            else if (int.TryParse(search, out i))
            {
                int j;
                j = Int32.Parse(search);
                query = "SELECT * FROM Trainers where Salary='" + j + "'or TrainerId='" + search + "'";
            }
            else
            {
                query = "SELECT * FROM Trainers where TrainerId='" + search + "' or TrainerName='" + search + "' or TrainerDOB='" + search + "' or TrainerGender='" + search + "' or TrainerEmail='" + search + "' or TrainerBranch='" + search + "' or TrainerPhone='" + search + "'";
            }
            SqlCommand cmd = new SqlCommand(query, conn);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Trainer t = new Trainer()
                {
                    TrainerId = reader.GetString(reader.GetOrdinal("TrainerId")),
                    TrainerName = reader.GetString(reader.GetOrdinal("TrainerName")),
                    TrainerDOB = reader.GetString(reader.GetOrdinal("TrainerDOB")),
                    TrainerGender = reader.GetString(reader.GetOrdinal("TrainerGender")),
                    TrainerEmail = reader.GetString(reader.GetOrdinal("TrainerEmail")),
                    TrainerPhone = reader.GetString(reader.GetOrdinal("TrainerPhone")),
                    TrainerBranch = reader.GetString(reader.GetOrdinal("TrainerBranch")),
                    salary = reader.GetInt32(reader.GetOrdinal("Salary")),
                };
                Trainers.Add(t);
            }
            conn.Close();
            return Trainers;

        }
    }
}
