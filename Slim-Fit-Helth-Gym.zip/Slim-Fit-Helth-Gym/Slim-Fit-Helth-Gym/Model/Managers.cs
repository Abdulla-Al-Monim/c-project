﻿using System;
using System.Collections;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Slim_Fit_Helth_Gym.Model
{
    class Managers
    {
        SqlConnection conn;
        public Managers()
        {
            try
            {
                conn = new SqlConnection("Server=DESKTOP-O3VM4NP;Database=Slimfit;User Id=sa;Password=12345678;");
            }
            catch(Exception e)
            {
                
            }
        }
        public void AddManager(Manager manager)
        {
            try
            {
                conn.Open();
                string query = "INSERT INTO Managers (ManagerId,ManagerName,ManagerAddress,MangerDOB,ManagerPassword) VALUES('" + manager.ManagerId + "','" + manager.ManagerName + "','" + manager.ManagerAddress + "','" + manager.ManagerDOB + "','" + manager.ManagerPassword + "')";
                SqlCommand cmd = new SqlCommand(query, conn);
                int result = cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception e)
            {
                
            }
   
        }
        public Manager AuthenticateUser(string ManagerName, string ManagerPassword)
        {
            try
            {
                conn.Open();
                Manager m = null;
                string query = "SELECT * FROM Managers WHERE ManagerName='" + ManagerName + "' and ManagerPassword='" + ManagerPassword + "'";
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    m = new Manager();
                    m.ManagerName = reader.GetString(reader.GetOrdinal("ManagerName"));
                    m.ManagerId = reader.GetInt32(reader.GetOrdinal("ManagerId"));
                    m.ManagerPassword = reader.GetString(reader.GetOrdinal("ManagerPassword"));
                    m.ManagerDOB = reader.GetString(reader.GetOrdinal("MangerDOB"));
                    m.ManagerAddress = reader.GetString(reader.GetOrdinal("ManagerAddress"));
                }
                conn.Close();
                return m;
            }
            catch (Exception e)
            {
                return null;
            }
            

        }
        public Manager AuthenticateManager(string managerId, string managerPassword)
        {
            try
            {
                conn.Open();
                Manager m = null;
                string query = "SELECT * FROM Managers WHERE ManagerId='" + managerId + "' and ManagerPassword='" + managerPassword + "'";
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    m = new Manager();
                    m.ManagerName = reader.GetString(reader.GetOrdinal("ManagerName"));
                    m.ManagerId = reader.GetInt32(reader.GetOrdinal("ManagerId"));
                    m.ManagerPassword = reader.GetString(reader.GetOrdinal("ManagerPassword"));
                    m.ManagerDOB = reader.GetString(reader.GetOrdinal("MangerDOB"));
                    m.ManagerAddress = reader.GetString(reader.GetOrdinal("ManagerAddress"));
                }
                conn.Close();
                return m;
            }
            catch (Exception e)
            {
                return null;
            }
           

        }
        public void ChangePassManager(Manager manager)
        {
            try
            {
                conn.Open();

                string query = "UPDATE  Managers set ManagerPassword = '" + manager.ManagerPassword + "' where ManagerId='" + manager.ManagerId + "'";


                SqlCommand cmd = new SqlCommand(query, conn);
                int result = cmd.ExecuteNonQuery();
                conn.Close();
            }
            catch (Exception e)
            {
                
            }
            
        }

        public ArrayList GetAllManager()
        {

            ArrayList Managers = new ArrayList();

            conn.Open();
            string query = "SELECT ManagerId,ManagerName,ManagerAddress,MangerDOB FROM Managers";
            SqlCommand cmd = new SqlCommand(query, conn);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Manager m = new Manager();

                m.ManagerId = reader.GetInt32(reader.GetOrdinal("ManagerId"));
                m.ManagerName = reader.GetString(reader.GetOrdinal("ManagerName"));
                m.ManagerAddress = reader.GetString(reader.GetOrdinal("ManagerAddress"));
                m.ManagerDOB = reader.GetString(reader.GetOrdinal("MangerDOB"));




                Managers.Add(m);
            }
            conn.Close();
            return Managers;

        }

    }
}
