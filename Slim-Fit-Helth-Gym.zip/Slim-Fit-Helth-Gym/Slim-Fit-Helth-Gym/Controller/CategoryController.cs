﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Slim_Fit_Helth_Gym.Model;

namespace Slim_Fit_Helth_Gym.Controller
{
    class CategoryController
    {
        static DataBase db = new DataBase();
        public static ArrayList GetAllMemberCategories()
        {
            return db.MemberCategories.GetAllMemberCategories();
        }

    }
    
}
