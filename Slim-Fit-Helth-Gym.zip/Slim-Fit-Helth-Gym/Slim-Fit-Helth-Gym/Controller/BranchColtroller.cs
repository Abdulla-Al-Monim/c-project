﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Slim_Fit_Helth_Gym.Model;

namespace Slim_Fit_Helth_Gym.Controller
{
    class BranchColtroller
    {
        public static DataBase db = new DataBase();
        public static ArrayList GetAllBranches()
        {
            return db.Branches.GetAllBranches();
        }
        public static void AddBranch(string place)
        {
            Branch b = new Branch()
            {
                Place=place
            };
            db.Branches.AddBranch(b);
        }
    }
}
