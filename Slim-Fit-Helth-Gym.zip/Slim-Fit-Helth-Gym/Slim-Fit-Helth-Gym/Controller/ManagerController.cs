﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Slim_Fit_Helth_Gym.Model;

namespace Slim_Fit_Helth_Gym.Controller
{
    class ManagerController
    {
        public static DataBase db = new DataBase();

        static public bool AuthenticateManager(string managerId, string managerPassword)
        {
            bool result = false;

            var obj = db.Managers.AuthenticateManager(managerId, managerPassword);
            if (obj != null) result = true;
            return result;
        }
        public static void ChangePassManager(string managerId, string password)
        {

            Manager m = new Manager()
            {
                ManagerId = Int32.Parse(managerId),
                ManagerPassword = password
            };
            db.Managers.ChangePassManager(m);
        }
        public static void AddManager(string managerId,string managerName,string address,string managerDOB,string password)
        {
            Manager m = new Manager()
            {
                ManagerId = Int32.Parse(managerId),
                ManagerName=managerName,
                ManagerAddress=address,
                ManagerDOB=managerDOB,
                ManagerPassword=password
            };
            db.Managers.AddManager(m);
        }
        public static ArrayList GetAllManager()
        {
            return db.Managers.GetAllManager();
        }
    }
}
